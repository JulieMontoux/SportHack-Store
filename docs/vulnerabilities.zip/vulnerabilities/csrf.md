# 🔒 CSRF

## Exercice

Simuler une requête POST dans un `<form>` externe pointant sur `/delete-product/3`

## Correction

Jeton anti-CSRF obligatoire dans les requêtes sensibles.
