# 🔟 Absence de Rate Limiting

## Description

Spam possible sans limitation.

## Exercice

- Rejouer en boucle le formulaire login sans limite.

## Correction

`express-rate-limit` en middleware.
