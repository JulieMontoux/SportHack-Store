# 🔒 Clickjacking

## Exercice

Intégrer l’app dans une iframe HTML extérieure.

## Correction

`X-Frame-Options: DENY`
