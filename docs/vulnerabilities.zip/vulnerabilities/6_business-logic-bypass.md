# 6️⃣ Business Logic Bypass

## Description

Contourner une logique métier ex: modifier prix en frontend avant POST.

## Exercice

- Modifier le montant d’un article dans DevTools avant validation panier.

## Correction

Le backend doit recalculer les montants serveur-side uniquement.
