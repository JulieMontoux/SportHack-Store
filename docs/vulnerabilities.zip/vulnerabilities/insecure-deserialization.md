# 🔒 Insecure Deserialization

## Exercice

Envoyer un objet JSON contenant des propriétés inattendues, ou un payload JavaScript dans des objets serialisés.

## Correction

Ne jamais désérialiser un objet sans le filtrer strictement.
