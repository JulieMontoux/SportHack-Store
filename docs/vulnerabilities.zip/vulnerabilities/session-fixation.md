# 🔒 Session Fixation

## Exercice

Injecter un token prédéfini avant login, vérifier s’il reste valide.

## Correction

Changer token après chaque login.
